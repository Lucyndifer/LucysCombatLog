package me.lucyn.lucyscombatlog;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class LucysCombatLog extends JavaPlugin {

    public Map<UUID, Long> timeMap;
    public Boolean disableContainers;
    public int delay;
    public String message;

    public static LucysCombatLog getPlugin() {
        return LucysCombatLog.getPlugin(LucysCombatLog.class);
    }

    @Override
    public void onEnable() {
        // Plugin startup logic
        timeMap = new HashMap<>();
        saveDefaultConfig();

        disableContainers = getConfig().getBoolean("disable-containers");
        delay = getConfig().getInt("delay");
        message = getConfig().getString("message");
        getServer().getPluginManager().registerEvents(new ContainerListener(), this);
        getServer().getPluginManager().registerEvents(new AttackListener(), this);
        getServer().getPluginManager().registerEvents(new LeaveListener(), this);

    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }

    public void setTimeMap(Player player) {
        UUID id = player.getUniqueId();
        timeMap.put(id, System.currentTimeMillis() + (delay * 1000L));
    }

    public Boolean getTimeMap(Player player) {
        UUID id = player.getUniqueId();
        if (timeMap.containsKey(id)) {
            if (timeMap.get(id) > System.currentTimeMillis()) return true;
             else timeMap.remove(id);
        }
        return false;
    }

}
