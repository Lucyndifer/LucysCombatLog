package me.lucyn.lucyscombatlog;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class AttackListener implements Listener {

    @EventHandler
    public void onPlayerAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player && event.getEntity() instanceof Player)) return;
        if(((Player) event.getDamager()).hasPermission("lucyscombatlog.exempt")) return;

        LucysCombatLog plugin = LucysCombatLog.getPlugin();

        plugin.setTimeMap((Player) event.getDamager());
        plugin.setTimeMap((Player) event.getEntity());

        ((Player) event.getDamager()).sendTitle(" ", plugin.message, 10, plugin.delay * 20, 10);
        ((Player) event.getEntity()).sendTitle(" ", plugin.message, 10, plugin.delay * 20, 10);



    }
}
