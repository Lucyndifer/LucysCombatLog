package me.lucyn.lucyscombatlog;

import org.bukkit.block.Container;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Dispenser;
import org.bukkit.block.data.type.Chest;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class ContainerListener implements Listener {

    @EventHandler
    public void onContainerInteract(InventoryOpenEvent event) {
        LucysCombatLog plugin = LucysCombatLog.getPlugin();
        if (plugin.disableContainers) {
           if(event.getInventory().getHolder() instanceof Player) return;
           else event.setCancelled(true);

        }

    }
}
