package me.lucyn.lucyscombatlog;

import jdk.internal.icu.impl.NormalizerImpl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

public class LeaveListener implements Listener {

    @EventHandler
    public void onPlayerLeave(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        LucysCombatLog plugin = LucysCombatLog.getPlugin();
        if(plugin.getTimeMap(player)) {
            player.setHealth(0);
        }
    }
}